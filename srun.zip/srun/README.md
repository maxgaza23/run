## For install Tutorial [HERE](https://www.youtube.com/watch?v=10H6ju83gO8&t=3s)
### Login dengan QR

# Ambil token via QR
