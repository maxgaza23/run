from linepy  import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from urllib.parse import urlencode
from tmp.MySplit import *
from random import randint
from Naked.toolshed.shell import execute_js
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback,livejson
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#==============================================================================#
with open("maxgie.txt","r") as z:
    token = z.read()
maxgie = LINE(token,appName="IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
#maxgie = LINE('',appName="IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
myMid = maxgie.getProfile().mid
oepoll = OEPoll(maxgie)
admin = ["ua8884f95e4751866567b46bfbdcb87cb"]

with open('spam.json', 'r') as fp:
    spam = json.load(fp)
#==============================================================================#

def log(text):
    global maxgie
    print("[%s] [%s] : %s" % (str(datetime.now()), maxgie.profile.displayName, text))
    
def rungroup(op):
    try:
        if op.type == 1:
            return
        if op.type == 25:
            msg = op.message
            text = msg.text
            to = msg.to
            msg_id = msg.id
            sender = msg._from
            if text is None: return
            elif text.lower().startswith("รัน "):
                          nm = text.replace("รัน ","")
                          if spam["list"] != {}:
                            imnoob = "spam.js name={} token={}".format(nm,maxgie.authToken)
                            for target in spam["list"]:
                              imnoob += " uid={}".format(target)
                            success = execute_js(imnoob)
                            if success:maxgie.sendMessage(msg.to,"Done")
                            else:maxgie.sendMessage(msg.to,"Error")
                          else:maxgie.sendMessage(msg.to,"ไม่มีคท..")
    except Exception as error:
        log(error)
        
def run():
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                    threads = []
                    for i in range(1):
                        thread = threading.Thread(target=rungroup(op))
                        threads.append(thread)
                        thread.start()
                        oepoll.setRevision(op.revision)
            for thread in threads:
                thread.join()
        except:
            pass
if __name__ == '__main__':
    run()