from linepy import LINE as MaxGie
from linepy import OEPoll
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad import ChannelService,TalkService
from akad.ttypes import Message, Location, LoginRequest, ChatRoomAnnouncementContents, ContentType as Type
from thrift.protocol import TCompactProtocol, TBinaryProtocol, TProtocol
from thrift.transport import THttpClient, TTransport
from thrift.Thrift import TProcessor
from time import sleep
from datetime import datetime, timedelta
import time, random, sys, json, codecs, glob, urllib, pytz, ast, os, multiprocessing, subprocess, tempfile, string, six, urllib.parse, traceback, atexit, html5lib, re, wikipedia, ntpath, threading, base64, shutil, humanize, LineService, os.path, youtube_dl, requests,livejson
#==============================================================================#
maxgie = MaxGie('')
#maxgie.log("Token : "+maxgie.authToken)

oepoll = OEPoll(maxgie)
myMid = maxgie.profile.mid
admin = ["u3dff2c5a35a54c332cff435ecdff7099"]
true = True
false = False
#==============================================================================#
with open('user.json', 'r') as fp:
    settings = json.load(fp)
with open('spam.json', 'r') as fp:
    spam = json.load(fp)
list = {"con":false, "uncon":false}
nama = "MaxGie"
Headersios = {
   'User-Agent': "Line/8.11.0",
   'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
   "x-lal": "ja-US_US",
}
def log(text):
    global maxgie
    print("[%s] [%s] : %s" % (str(datetime.now()), maxgie.profile.displayName, text))

def restartBot():
    print ("[ INFO ] BOT RESTART")
    python = sys.executable
    os.execl(python, python, *sys.argv)

def backupData():
    try:
        backup = settings
        f = codecs.open('user.json','w','utf-8')
        json.dump(settings, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = spam
        f = codecs.open('spam.json','w','utf-8')
        json.dump(spam, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except:
        pass

#FlexMessage  
def Flex(to, data): 
    ratedit = LiffChatContext(to)
    ratedit1 = LiffContext(chat=ratedit)
    view = LiffViewRequest('1602687308-GXq4Vvk9', ratedit1)
    token = maxgie.liff.issueLiffView(view)
    api_url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(api_url, headers=headers, data=json.dumps(data))

def maxgiebot(op):
    try:
        if op.type == 0:
            return
        if op.type == 13:
            maxgie.acceptGroupInvitation(op.param1)
        if op.type in [26]:
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            isValid = True
            if isValid != False:
                if msg.toType == 0 and sender != myMid: to = sender
                else: to = receiver
                if msg.contentType == 13:
                  mid = msg.contentMetadata['mid']
                  if list["con"] == true:
                    if msg._from in settings["user"] or sender in admin:
                      if mid in spam["list"]:
                          maxgie.sendMessage(to, "มีอยู่ในบัญชีรันแล้ว")
                      else:
                          spam["list"][mid] = True
                          maxgie.sendMessage(to, "เพิ่มเข้าบัญชีรันเรียบร้อย")
                  if list["uncon"] == true:
                    if msg._from in settings["user"] or sender in admin:
                      if mid in spam["list"]:
                          del spam["list"][mid]
                          maxgie.sendMessage(to, "ยกคท.ออกบัญชีรันเรียบร้อย")
                      else:
                          maxgie.sendMessage(to, "คท.นี้ไม่มีในบัญชีรัน")
        if op.type == 26:
            msg = op.message
            text = msg.text
            to = msg.to
            msg_id = msg.id
            sender = msg._from
            if text is None: return
            if text.lower() == "คำสั่ง":
             if sender in settings["user"] or sender in admin:
                ss = "----- คำสั่งบอทรัน -----\n"
                ss += "1. เปิดรัน/ปิดรัน\n"
                ss += "เป็นคำสั่งเพิ่มคทรันพอเพิ่มเสร็จให้พิม ปิดรัน ด้วย\n"
                ss += "2. เปิดยก/ปิดยก\n"
                ss += "เป็นคำสั่งยกคทรันพอยกเสร็จให้พิม ปิดยก ด้วย\n"
                ss += "3. เช็คชื่อ/เช็คคท\n"
                ss += "เป็นคำสั่งเช็คดูรายชื่อที่เราจะรัน\n"
                ss += "4. ลิ้งรัน\n"
                ss += "เป็นคำสั่งส่งลิ้งในร่างรันกด\n"
                ss += "5. ล้างคท\n"
                ss += "เป็นคำสั่งล้างคทที่เราเพิ่มไปทั่งหมด\n"
                ss += "6. ออกระบบ\n"
                ss += "เป็นคำสั่งออกระบบทุกครั้งที่รันเสร็จ >_<"
                maxgie.sendMessage(to, ss)
            if text.lower() == "เปิดรัน":
             if sender in settings["user"] or sender in admin:
                list["con"] = true
                maxgie.sendMessage(to, "ส่ง contact มา")
            if text.lower() == "ปิดรัน":
             if sender in settings["user"] or sender in admin:
                list["con"] = false
                maxgie.sendMessage(to, "ปิดเพิ่ม คท รันแล้ว")
            if text.lower() == "เปิดยก":
             if sender in settings["user"] or sender in admin:
                list["uncon"] = true
                maxgie.sendMessage(to, "ส่ง contact มา")
            if text.lower() == "ปิดยก":
             if sender in settings["user"] or sender in admin:
                list["uncon"] = false
                maxgie.sendMessage(to, "ปิดยก คท รันแล้ว")
            if text.lower() == "ล้างคท":
              if sender in settings["user"] or sender in admin:
                  spam["list"] = {}
                  maxgie.sendMessage(to, "ล้างคททั้งหมดแล้ว")
            if text.lower() == "เช็คคท":
               if sender in settings["user"] or sender in admin:
                        if spam["list"] == {}:
                            maxgie.sendMessage(to, "ไม่มี contact ที่จะรัน")
                        else:
                            for bl in spam["list"]:
                                 maxgie.sendMessage(to, text=None, contentMetadata={'mid': bl}, contentType=13)
            elif text.lower() == "เช็คชื่อ":
              if sender in settings["user"] or sender in admin:
                if spam["list"] == {}:
                    maxgie.sendMessage(to, "ไม่มีรายชื่อที่จะรัน")
                else:
                    ma = ""
                    a = 0
                    for m_id in spam["list"]:
                        a = a + 1
                        ma += "\n"+str(a)+". "+maxgie.getContact(m_id).displayName
                    maxgie.sendMessage(to,"รายชื่อคทที่จะรัน :"+ma)
            if text.lower() == "reset":
              if sender in admin: 
                  maxgie.sendMessage(to, "กำลังทำการระบบใหม่กรุณารอสักครู่...")
                  restartBot()
            elif text.lower() == "user":
               if sender in admin:
                 if settings["user"] == {}:
                     maxgie.sendMessage(to, "ไม่มีรายผู้ใช้งาน")
                 else:
                     ma = ""
                     for m_id in settings["user"]:
                         ma += "\n- "+maxgie.getContact(m_id).displayName
                     maxgie.sendMessage(to,"รายชื่อผู้ใช้งาน :"+ma)
            if text.lower().startswith('adduser '):
              if sender in admin:
                  if 'MENTION' in msg.contentMetadata.keys()!= None:
                      key = eval(msg.contentMetadata["MENTION"])
                      key1 = key["MENTIONEES"][0]["M"]
                      if key1 not in settings["user"]:
                          sa = str(text.split(' ')[1])
                          settings['user'][key1] =  '%s' % sa
                          maxgie.sendMessage(to, "เพิ่ม {n} เป็นผู้ใช้งานเรียบร้อย\nอย่าลืมปิด letter sealing ด้วยนะครับ\nline://nv/settings/privacy".format(n=maxgie.getContact(key1).displayName))
                      else:
                          maxgie.sendMessage(to, "คุณ {n} ได้อยู่ในผู้ใช้งานอยู่แล้ว".format(n=maxgie.getContact(key1).displayName))
            if text.lower().startswith('deluser '):
              if sender in admin:
                  if 'MENTION' in msg.contentMetadata.keys()!= None:
                      key = eval(msg.contentMetadata["MENTION"])
                      key1 = key["MENTIONEES"][0]["M"]
                      if key1 in settings["user"]:
                          d = settings["user"][key1]
                          os.system('screen -S %s -X kill'%d)
                          try:subprocess.getoutput('rm -rf {}'.format(d))
                          except:pass
                          del settings["user"][key1]
                          maxgie.sendMessage(to, "ลบ {n} ออกจากผู้ใช้งานเรียบร้อย".format(n=maxgie.getContact(key1).displayName))
                      else:
                          maxgie.sendMessage(to, "คุณ {n} ไม่ได้อยู่ในผู้ใช้งานอยู่แล้ว".format(n=maxgie.getContact(key1).displayName))
                 
            if text.lower() == "ลิ้งรัน" or text.lower() == "ล็อคอินรัน":
              if sender in settings["user"] or sender in admin:
                  try:
                       def selfrun():
                           user = settings["user"][sender]
                           Headersios.update({'x-lpqs' : '/api/v4/TalkService.do'})
                           transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4/TalkService.do')
                           transport.setCustomHeaders(Headersios)
                           protocol = TCompactProtocol.TCompactProtocol(transport)
                           login = LineService.Client(protocol)
                           qr = login.getAuthQrcode(keepLoggedIn=1, systemName=nama)
                           link = "line://au/q/" + qr.verifier
                           maxgie.sendMessage(to, "กรุณากดลิ้งภายใน 2 นาที\n"+link)
                           Headersios.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                           json.loads(requests.session().get('https://gd2.line.naver.jp/Q', headers=Headersios).text)
                           Headersios.update({'x-lpqs' : '/api/v4p/rs'})
                           transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4p/rs')
                           transport.setCustomHeaders(Headersios)
                           protocol = TCompactProtocol.TCompactProtocol(transport)
                           login = LineService.Client(protocol)
                           req = LoginRequest()
                           req.type = 1
                           req.verifier = qr.verifier
                           req.e2eeVersion = 1
                           res = login.loginZ(req)
                           token = res.authToken
                           os.system('screen -S {} -X kill'.format(user))
                           os.system('cp -r run {}'.format(user))
                           os.system('cp -r spam.json {}'.format(user))
                           os.system('cd {} && echo -n "{} \c" > maxgie.txt'.format(user, token))
                           os.system('screen -dmS {}'.format(user))
                           os.system('screen -r {} -X stuff "cd {} && python3 run.py \n"'.format(user, user))
                           maxgie.sendMessage(to, "ล็อคอินเชลรันเรียบร้อย\nกรุณาพิม'รัน ชื่อกลุ่ม'ด้วยนะครับ")
                       threads = threading.Thread(target=selfrun)
                       threads.daemon = True
                       threads.start()
                  except:
                       pass
              else:
                 maxgie.sendMessage(to, "ไม่พบคุณอยู่ในรายชื่อผู้ใช้งาน")
                 
            if text.lower() == "out" or text.lower() == "ออกระบบ":
              if sender in settings["user"] or sender in admin:
                  us = settings["user"][sender]
                  os.system('screen -S {} -X quit'.format(us))
                  os.system('rm -rf {}'.format(us))
                  if msg.toType == 2:
                      maxgie.sendMessage(to, "คุณ {} ได้ทำการออกจากระบบเรียบร้อย".format(maxgie.getContact(sender).displayName))
                  else:
                      maxgie.sendMessage(to, "คุณ {} ไม่ได้อยู่ในระบบอยู่แล้ว".format(maxgie.getContact(sender).displayName))
    except Exception as error:
        log(error)
#==============================================================================#
def run():
    while True:
        try:
            backupData()
            ops = oepoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                    threads = []
                    for i in range(1):
                        thread = threading.Thread(target=maxgiebot(op))
                        threads.append(thread)
                        thread.start()
                        oepoll.setRevision(op.revision)
            for thread in threads:
                thread.join()
        except:
            pass
if __name__ == '__main__':
    run()